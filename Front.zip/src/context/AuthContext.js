import React, { createContext, useState, useContext, useEffect } from 'react';
import axios from 'axios';
import { API_URL } from '../config';

// Crear el contexto de autenticaci�n
const AuthContext = createContext();

// Hook personalizado
export const useAuth = () => useContext(AuthContext);

// Proveedor de autenticaci�n
export const AuthProvider = ({ children }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [user, setUser] = useState(null);
    const [initialized, setInitialized] = useState(false);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchAuthStatus = async () => {
            try {
                // Petici�n al backend para obtener el usuario autenticado (Negotiate)
                const response = await axios.get(`${API_URL}/api/user/current`, {
                    withCredentials: true
                });

                if (response.data && response.data.username) {
                    setUser(response.data);
                    setIsAuthenticated(true);
                } else {
                    setIsAuthenticated(false);
                }
            } catch (err) {
                console.error('Error al verificar el estado de autenticaci�n:', err);
                setIsAuthenticated(false);
            } finally {
                setLoading(false);
                setInitialized(true);
            }
        };

        fetchAuthStatus();
    }, []);

    const logout = () => {
        setIsAuthenticated(false);
        setUser(null);
        // Si implement�s logout con frontend + backend, se puede hacer aqu�.
    };

    const value = {
        isAuthenticated,
        user,
        loading,
        initialized,
        logout
    };

    return (
        <AuthContext.Provider value={value}>
            {children}
        </AuthContext.Provider>
    );
};
